﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace train.Hubs
{
    [Authorize(Policy = "AdminOnly")]
    public class StockHub : Hub
    {
        public const string GroupName = "Admins";
        public override async Task OnConnectedAsync()
        {
            await Groups.AddToGroupAsync(Context.ConnectionId, GroupName);
            await base.OnConnectedAsync();
        }
    }
}
