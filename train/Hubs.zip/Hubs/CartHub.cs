﻿using Microsoft.AspNetCore.SignalR;
namespace train.Hubs { public class CartHub : Hub { } 
}
