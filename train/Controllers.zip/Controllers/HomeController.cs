using Microsoft.AspNetCore.Mvc;
using train.Repositories.Interface;      // IProductRepository
using train.Repositories.Abstractions;   // ICategoryRepository (optional)
using train.ViewModels;

namespace train.Controllers
{
    public class HomeController : Controller
    {
        private readonly IProductRepository _products;

        public HomeController(IProductRepository products)
        {
            _products = products;
        }

        public async Task<IActionResult> Index()
        {
            var vm = new HomePageViewModel
            {
                // Pull last 7 days across all audiences; adjust page/pageSize to taste
                NewArrivals = await _products.GetNewInAsync(days: 7, audience: null, page: 1, pageSize: 8),
                Essentials = await _products.GetEssentialsAsync(audience: null, page: 1, pageSize: 8),
                Title = "Welcome to our store",
                Subtitle = "Fresh drops & everyday essentials"
            };

            return View(vm);
        }

        public IActionResult Privacy() => View();
    }
}
