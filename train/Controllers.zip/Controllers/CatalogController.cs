﻿// Controllers/CatalogController.cs
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using train.Repositories.Abstractions;   // ICategoryRepository
using train.Repositories.Interface;      // IProductRepository
using train.ViewModels;

namespace train.Controllers
{
    [AllowAnonymous]
    [Route("catalog")]
    public class CatalogController : Controller
    {
        private readonly IProductRepository _products;
        private readonly ICategoryRepository _categories;

        public CatalogController(IProductRepository products, ICategoryRepository categories)
        {
            _products = products;
            _categories = categories;
        }

        // ========= Core browse =========
        // GET /catalog
        [HttpGet("")]
        public async Task<IActionResult> Index(
            string? q,
            int? categoryId,
            string? audience = "Men",
            string? color = null,
            int page = 1,
            int pageSize = 12)
        {
            audience ??= "Men";

            var items = await _products.GetAllAsync(q, categoryId, audience, color, page, pageSize);
            var total = await _products.CountAsync(q, categoryId, audience, color);

            var vm = await BuildCatalogVm(
                mode: "Browse",
                audience: audience,
                items: items,
                total: total,
                q: q,
                categoryId: categoryId,
                color: color,
                page: page,
                pageSize: pageSize
            );

            return View(vm); // Views/Catalog/Index.cshtml
        }

        // ========= New In (last N days) =========
        // GET /catalog/new
        [HttpGet("new")]
        public async Task<IActionResult> NewIn(
            string? audience = "Men",
            int days = 3,
            int page = 1,
            int pageSize = 12)
        {
            audience ??= "Men";

            var items = await _products.GetNewInAsync(days, audience, page, pageSize);
            var total = await _products.CountNewInAsync(days, audience);

            var vm = await BuildCatalogVm(
                mode: "NewIn",
                audience: audience,
                items: items,
                total: total,
                q: null,
                categoryId: null,
                color: null,
                page: page,
                pageSize: pageSize,
                days: days
            );

            return View("Index", vm); // reuse same view
        }

        // ========= Essentials (all collection) =========
        // GET /catalog/essentials
        [HttpGet("essentials")]
        public async Task<IActionResult> Essentials(
            string? audience = "Men",
            int page = 1,
            int pageSize = 12)
        {
            audience ??= "Men";

            var items = await _products.GetEssentialsAsync(audience, page, pageSize);
            var total = await _products.CountEssentialsAsync(audience);

            var vm = await BuildCatalogVm(
                mode: "Essentials",
                audience: audience,
                items: items,
                total: total,
                q: null,
                categoryId: null,
                color: null,
                page: page,
                pageSize: pageSize
            );

            return View("Index", vm); // reuse same view
        }

        // ========= Gender shortcuts (nice URLs) =========
        // Browse
        [HttpGet("men")] public IActionResult Men() => RedirectToAction(nameof(Index), new { audience = "Men" });
        [HttpGet("women")] public IActionResult Women() => RedirectToAction(nameof(Index), new { audience = "Women" });
        [HttpGet("boys")] public IActionResult Boys() => RedirectToAction(nameof(Index), new { audience = "Boys" });
        [HttpGet("girls")] public IActionResult Girls() => RedirectToAction(nameof(Index), new { audience = "Girls" });

        // New In
        [HttpGet("men/new")] public IActionResult MenNew() => RedirectToAction(nameof(NewIn), new { audience = "Men", days = 3 });
        [HttpGet("women/new")] public IActionResult WomenNew() => RedirectToAction(nameof(NewIn), new { audience = "Women", days = 3 });
        [HttpGet("boys/new")] public IActionResult BoysNew() => RedirectToAction(nameof(NewIn), new { audience = "Boys", days = 3 });
        [HttpGet("girls/new")] public IActionResult GirlsNew() => RedirectToAction(nameof(NewIn), new { audience = "Girls", days = 3 });

        // Essentials
        [HttpGet("men/essentials")] public IActionResult MenEssentials() => RedirectToAction(nameof(Essentials), new { audience = "Men" });
        [HttpGet("women/essentials")] public IActionResult WomenEssentials() => RedirectToAction(nameof(Essentials), new { audience = "Women" });
        [HttpGet("boys/essentials")] public IActionResult BoysEssentials() => RedirectToAction(nameof(Essentials), new { audience = "Boys" });
        [HttpGet("girls/essentials")] public IActionResult GirlsEssentials() => RedirectToAction(nameof(Essentials), new { audience = "Girls" });

        // ========= Details (unchanged) =========
        [HttpGet("details/{id:int}")]
        public async Task<IActionResult> Details(int id)
        {
            var product = await _products.GetByIdAsync(id);
            if (product == null) return NotFound();
            return View(product);
        }

        // ========= Helpers =========
        private async Task<CatalogIndexViewModel> BuildCatalogVm(
            string mode,
            string audience,
            IEnumerable<train.Models.Product> items,
            int total,
            string? q,
            int? categoryId,
            string? color,
            int page,
            int pageSize,
            int days = 3)
        {
            // Limit category list to the chosen audience
            var cats = await _categories.GetByAudienceAsync(audience, q);
            var catSelect = cats
                .Select(c => new SelectListItem(c.Name, c.Id.ToString(), c.Id == categoryId))
                .ToList();

            return new CatalogIndexViewModel
            {
                Mode = mode,           // "Browse" | "NewIn" | "Essentials"
                Days = days,           // used when Mode == "NewIn"
                Products = items,
                Query = q,
                CategoryId = categoryId,
                Categories = catSelect,
                Audience = audience,
                SelectedColor = color,
                Colors = GetColorOptions(color),
                Page = page,
                PageSize = pageSize,
                TotalCount = total
            };
        }

        private static List<SelectListItem> GetColorOptions(string? selected)
        {
            var colors = new[]
            {
        "Black", "White", "Gray", "Navy", "Blue", "Red",
        "Green", "Yellow", "Purple", "Pink", "Brown", "Beige"
    };

            var list = new List<SelectListItem> { new("All Colors", "") };
            foreach (var c in colors)
                list.Add(new SelectListItem(c, c, !string.IsNullOrEmpty(selected) &&
                    string.Equals(selected, c, StringComparison.OrdinalIgnoreCase)));
            return list;
        }

    }
}
