﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using train.Repositories.Interface;      // IProductRepository
using train.Repositories.Abstractions;   // ICategoryRepository
using train.ViewModels;
using train.Models;

namespace train.Controllers
{
    [Authorize(Policy = "AdminOnly")]
    [Route("admin/products")]
    public class ProductsController : Controller
    {
        private readonly IProductRepository _products;
        private readonly ICategoryRepository _categories;

        public ProductsController(IProductRepository products, ICategoryRepository categories)
        {
            _products = products;
            _categories = categories;
        }

        // READ: List
        [HttpGet("")]
        public async Task<IActionResult> Index(string? q, int? categoryId, string? audience, string? color, int page = 1, int pageSize = 10)
        {
            // NOTE: 'color' is now matched via Category.Color inside the repository
            var items = await _products.GetAllAsync(q, categoryId, audience, color, page, pageSize);
            var total = await _products.CountAsync(q, categoryId, audience, color);

            ViewBag.Query = q;
            ViewBag.CategoryId = categoryId;
            ViewBag.Audience = audience;
            ViewBag.Color = color;
            ViewBag.Page = page;
            ViewBag.PageSize = pageSize;
            ViewBag.Total = total;

            var cats = await _categories.GetAllAsync(null, null, null, 1, int.MaxValue);
            ViewBag.Categories = cats.Select(c => new SelectListItem(c.Name, c.Id.ToString()));

            return View(items);
        }

        // READ: Details
        [HttpGet("details/{id:int}")]
        public async Task<IActionResult> Details(int id)
        {
            var p = await _products.GetByIdAsync(id);
            if (p == null) return NotFound();
            return View(p);
        }

        private async Task<IEnumerable<SelectListItem>> CategoryItemsFor(string audience, int? selectedId = null)
        {
            var cats = await _categories.GetByAudienceAsync(audience, null);

            string Label(train.Models.Category c) =>
                string.IsNullOrWhiteSpace(c.Color) ? c.Name : $"{c.Name} ({c.Color})";

            return cats.Select(c => new SelectListItem(
                Label(c),
                c.Id.ToString(),
                selectedId.HasValue && c.Id == selectedId.Value));
        }


        // CREATE: GET
        [HttpGet("create")]
        public async Task<IActionResult> Create()
        {
            var vm = new ProductFormViewModel
            {
                TargetAudience = "Men",
                Categories = await CategoryItemsFor("Men")
            };
            return View(vm);
        }

        // CREATE: POST
        [HttpPost("create")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ProductFormViewModel vm)
        {
            if (!vm.CategoryId.HasValue)
                ModelState.AddModelError(nameof(vm.CategoryId), "Please select a category.");

            if (!ModelState.IsValid)
            {
                var cats = await _categories.GetByAudienceAsync(vm.TargetAudience, q: null);
                vm.Categories = cats.Select(c => new SelectListItem(c.Name, c.Id.ToString(), c.Id == vm.CategoryId));
                return View(vm);
            }

            var catId = vm.CategoryId!.Value;

            // audience/category guard
            var cat = await _categories.GetByIdAsync(catId);
            if (cat == null || !string.Equals(cat.TargetAudience, vm.TargetAudience, StringComparison.OrdinalIgnoreCase))
            {
                ModelState.AddModelError(nameof(vm.CategoryId), "Selected category doesn't match the selected audience.");
                var cats = await _categories.GetByAudienceAsync(vm.TargetAudience, q: null);
                vm.Categories = cats.Select(c => new SelectListItem(c.Name, c.Id.ToString(), c.Id == vm.CategoryId));
                return View(vm);
            }

            var product = vm.ToEntity();
            await _products.AddAsync(product);
            TempData["Ok"] = "Product created.";
            return RedirectToAction(nameof(Index));
        }

        // EDIT: GET
        [HttpGet("edit/{id:int}")]
        public async Task<IActionResult> Edit(int id)
        {
            var p = await _products.GetByIdAsync(id);
            if (p is null) return NotFound();

            var vm = ProductFormViewModel.FromEntity(p);
            vm.Categories = await CategoryItemsFor(vm.TargetAudience, vm.CategoryId);
            return View(vm);
        }

        // EDIT: POST
        [HttpPost("edit/{id:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, ProductFormViewModel vm)
        {
            if (id != vm.Id) return BadRequest();

            if (!vm.CategoryId.HasValue)
                ModelState.AddModelError(nameof(vm.CategoryId), "Please select a category.");

            if (!ModelState.IsValid)
            {
                var cats = await _categories.GetByAudienceAsync(vm.TargetAudience, q: null);
                vm.Categories = cats.Select(c => new SelectListItem(c.Name, c.Id.ToString(), c.Id == vm.CategoryId));
                return View(vm);
            }

            var catId = vm.CategoryId!.Value;

            var product = await _products.GetByIdAsync(id);
            if (product == null) return NotFound();

            // audience/category guard
            var cat = await _categories.GetByIdAsync(catId);
            if (cat == null || !string.Equals(cat.TargetAudience, vm.TargetAudience, StringComparison.OrdinalIgnoreCase))
            {
                ModelState.AddModelError(nameof(vm.CategoryId), "Selected category doesn't match the selected audience.");
                var cats = await _categories.GetByAudienceAsync(vm.TargetAudience, q: null);
                vm.Categories = cats.Select(c => new SelectListItem(c.Name, c.Id.ToString(), c.Id == vm.CategoryId));
                return View(vm);
            }

            // Apply changes (color & isOnSale removed)
            product.Name = vm.Name;
            product.Description = vm.Description;
            product.Price = vm.Price;
            product.Stock = vm.Stock;
            product.ImageUrl = vm.ImageUrl;
            product.CategoryId = catId;
            product.TargetAudience = vm.TargetAudience;

            await _products.UpdateAsync(product);
            TempData["Ok"] = "Product updated.";
            return RedirectToAction(nameof(Index));
        }

        // DELETE: GET
        [HttpGet("delete/{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var p = await _products.GetByIdAsync(id);
            if (p == null) return NotFound();
            return View(p);
        }

        // DELETE: POST
        [HttpPost("delete/{id:int}")]
        [ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _products.DeleteAsync(id);
            TempData["Ok"] = "Product deleted.";
            return RedirectToAction(nameof(Index));
        }


    }
}
