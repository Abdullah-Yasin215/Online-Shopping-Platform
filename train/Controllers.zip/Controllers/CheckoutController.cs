﻿using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;          // ✅ SignalR
using train.Repositories.Abstractions;
using train.ViewModels;
using train.Hubs;
using train.Repositories.Interface;
using train.Areas.Identity.Data;

namespace train.Controllers
{
    [AllowAnonymous]
    [Route("checkout")]
    public class CheckoutController : Controller
    {
        private readonly ICartRepository _carts;
        private readonly IOrderRepository _orders;
        private readonly appdbcontext _db;

        public CheckoutController(ICartRepository carts, IOrderRepository orders,appdbcontext db)
        {
            _db = db;
            _carts = carts;
            _orders = orders;
        }

        private string? CurrentUserId =>
            User.Identity?.IsAuthenticated == true
              ? User.FindFirstValue(ClaimTypes.NameIdentifier)
              : null;

        private string GetOrSetSessionId()
        {
            const string cookieName = "sf_sid";
            if (!Request.Cookies.TryGetValue(cookieName, out var sid) || string.IsNullOrWhiteSpace(sid))
            {
                sid = Guid.NewGuid().ToString("N");
                Response.Cookies.Append(cookieName, sid, new CookieOptions
                {
                    HttpOnly = true,
                    IsEssential = true,
                    Expires = DateTimeOffset.UtcNow.AddDays(30)
                });
            }
            return sid;
        }

        // GET /checkout
        [HttpGet("")]
        public async Task<IActionResult> Review()
        {
            var sid = GetOrSetSessionId();
            if (CurrentUserId != null)
                await _carts.AttachCartToUserAsync(CurrentUserId, sid);

            var cart = await _carts.GetOrCreateAsync(CurrentUserId, sid);

            var vm = new CartIndexViewModel
            {
                Items = cart.Items.Select(i => new CartLineViewModel
                {
                    ProductId = i.ProductId,
                    Name = i.Product?.Name ?? "Product",
                    ImageUrl = i.Product?.ImageUrl,
                    Category = i.Product?.Category?.Name,
                    Color = i.Product?.Category?.Color,
                    UnitPrice = i.UnitPrice,
                    Quantity = i.Quantity
                }).ToList()
            };
            vm.TotalQuantity = vm.Items.Sum(x => x.Quantity);
            vm.Subtotal = vm.Items.Sum(x => x.LineTotal);
            return View(vm);
        }



        // POST /checkout/place  (must be logged in)
        [Authorize]
        [HttpPost("place")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Place(
            [FromServices] IHubContext<AdminHub> adminHub, // ✅ keep
            [FromServices] IHubContext<StockHub> hub,      // ✅ keep
            [FromServices] IHubContext<CartHub> cartHub,   // ✅ NEW
            [FromServices] IHubContext<OrderHub> orderHub) // ✅ NEW
        {
            var sid = GetOrSetSessionId();

            // merge session cart into user's cart before placing
            await _carts.AttachCartToUserAsync(CurrentUserId!, sid);

            var (ok, error, order) = await _orders.PlaceOrderAsync(CurrentUserId!, sid);
            if (!ok || order == null)
            {
                TempData["Error"] = error ?? "Could not place order.";
                return RedirectToAction(nameof(Review));
            }

            // ✅ notify all connected admins in real time (existing AdminHub path)
            await adminHub.Clients.Group("Admins").SendAsync("OrderCreated", new
            {
                id = order.Id,
                date = order.OrderDate,      // matches your model
                status = order.Status,
                total = order.TotalAmount
                // add more fields if you have them (e.g., customerEmail)
            });

            // ✅ also notify via OrderHub (renamed admin hub route)
            await orderHub.Clients.Group(OrderHub.GroupName).SendAsync("OrderCreated", new
            {
                id = order.Id,
                date = order.OrderDate,
                status = order.Status,
                total = order.TotalAmount
            });

            // ✅ (optional) notify the current user on CartHub (e.g., toast on the site)
            if (CurrentUserId is not null)
            {
                await cartHub.Clients.User(CurrentUserId).SendAsync("OrderPlaced", new
                {
                    id = order.Id,
                    total = order.TotalAmount,
                    items = order.Items.Sum(i => i.Quantity)
                });
            }

            TempData["Ok"] = $"Order #{order.Id} placed successfully.";
            return RedirectToAction("Details", "MyOrders", new { id = order.Id });
        }

        // GET /checkout/info (collect contact/shipping)
        [HttpGet("info")]
        public async Task<IActionResult> Info()
        {
            var userId = CurrentUserId;
            var sessionId = GetOrSetSessionId();

            var cart = await _carts.GetAsync(userId, sessionId);
            if (cart == null || cart.Items.Count == 0)
                return RedirectToAction("Index", "Cart");

            var vm = new CheckoutInfoVm
            {
                Items = cart.Items.Select(i => new CheckoutItemVm
                {
                    ProductName = i.Product?.Name ?? "",
                    Quantity = i.Quantity,
                    UnitPrice = i.UnitPrice,
                    Color = i.Product?.Category?.Color,
                    CategoryName = i.Product?.Category?.Name
                }).ToList(),
                Subtotal = _carts.Total(cart),
                ShippingFee = 0,
                Discount = 0,
                TotalAmount = _carts.Total(cart)
            };

            return View(vm);
        }

        [HttpPost("info")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Info(CheckoutInfoVm model,
    [FromServices] IHubContext<AdminHub> adminHub,
    [FromServices] IHubContext<StockHub> stockHub,
    [FromServices] IHubContext<CartHub> cartHub,
    [FromServices] IHubContext<OrderHub> orderHub)
        {
            if (!ModelState.IsValid)
                return View(model);

            var userId = CurrentUserId;
            var sessionId = GetOrSetSessionId();

            // merge session cart
            await _carts.AttachCartToUserAsync(userId, sessionId);

            // pass contact + shipping info into PlaceOrderAsync
            var (ok, error, order) = await _orders.PlaceOrderAsync(
                userId,
                sessionId,
                model.ContactName,
                model.ContactEmail,
                model.ContactPhone,
                model.City,
                model.PostalCode,
                model.ShippingAddress
            );

            if (!ok || order == null)
            {
                TempData["Error"] = error ?? "Could not place order.";
                return View(model);
            }

            // notify hubs (optional)
            await adminHub.Clients.Group("Admins").SendAsync("OrderCreated", new
            {
                id = order.Id,
                date = order.OrderDate,
                status = order.Status,
                total = order.TotalAmount
            });

            await orderHub.Clients.Group(OrderHub.GroupName).SendAsync("OrderCreated", new
            {
                id = order.Id,
                date = order.OrderDate,
                status = order.Status,
                total = order.TotalAmount
            });

            if (userId is not null)
            {
                await cartHub.Clients.User(userId).SendAsync("OrderPlaced", new
                {
                    id = order.Id,
                    total = order.TotalAmount,
                    items = order.Items.Sum(i => i.Quantity)
                });
            }

            TempData["Ok"] = $"Order #{order.Id} placed successfully.";
            return RedirectToAction("Details", "MyOrders", new { id = order.Id });
        }



        // Optional confirmation page
        [HttpGet("confirmation/{id:int}")]
        public async Task<IActionResult> Confirmation(int id)
        {
            var o = await _orders.GetByIdAsync(id);
            if (o == null) return NotFound();

            var vm = new OrderConfirmationViewModel
            {
                OrderId = o.Id,
                PlacedAtUtc = o.OrderDate,
                Status = o.Status,
                Total = o.TotalAmount,
                Items = o.Items.Select(i => new OrderLineVM
                {
                    Name = i.ProductName,
                    Category = i.CategoryName,
                    Color = i.Color,
                    UnitPrice = i.UnitPrice,
                    Quantity = i.Quantity,
                    LineTotal = i.LineTotal
                }).ToList()
            };

            return View(vm);
        }
    }
}
