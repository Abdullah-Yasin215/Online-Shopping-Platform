﻿using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using train.Hubs;
using train.Repositories.Abstractions;  // ICartRepository
using train.Repositories.Interface;     // IProductRepository
using train.ViewModels;

namespace train.Controllers
{
    [AllowAnonymous]
    [Route("cart")]
    public class CartController : Controller
    {
        private readonly ICartRepository _carts;
        private readonly IProductRepository _products;
        private readonly IOrderRepository _order;

        public CartController(ICartRepository carts, IProductRepository products, IOrderRepository order)
        {
            _carts = carts;
            _products = products;
            _order = order;
        }

        // ===== helpers =====
        private (string? userId, string sessionId) Auth()
        {
            string? userId = User.Identity?.IsAuthenticated == true
                ? User.FindFirstValue(ClaimTypes.NameIdentifier)
                : null;

            const string cookieName = "sf_sid";
            if (!Request.Cookies.TryGetValue(cookieName, out var sid) || string.IsNullOrWhiteSpace(sid))
            {
                sid = Guid.NewGuid().ToString("N");
                Response.Cookies.Append(cookieName, sid, new CookieOptions
                {
                    HttpOnly = true,
                    IsEssential = true,
                    Expires = DateTimeOffset.UtcNow.AddDays(30)
                });
            }
            return (userId, sid);
        }

        private static CartIndexViewModel BuildVm(Cart cart)
        {
            var vm = new CartIndexViewModel
            {
                Items = cart.Items.Select(i => new CartLineViewModel
                {
                    ProductId = i.ProductId,
                    Name = i.Product?.Name ?? "Product",
                    ImageUrl = i.Product?.ImageUrl,
                    Category = i.Product?.Category?.Name,
                    Color = i.Product?.Category?.Color,
                    UnitPrice = i.UnitPrice,
                    Quantity = i.Quantity
                }).ToList()
            };
            vm.TotalQuantity = vm.Items.Sum(x => x.Quantity);
            vm.Subtotal = vm.Items.Sum(x => x.LineTotal);
            return vm;
        }

        // ===== browse cart =====
        [HttpGet("")]
        public async Task<IActionResult> Index()
        {
            var (userId, sid) = Auth();
            var cart = await _carts.GetOrCreateAsync(userId, sid);
            var vm = BuildVm(cart);
            ViewBag.CartCount = vm.TotalQuantity;
            return View(vm); // Views/Cart/Index.cshtml
        }

        // ===== add =====
        [HttpPost("add")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(int productId,
            [FromServices] IHubContext<CartHub> cartHub,
            int qty = 1,
            string? returnUrl = null)
        {
            var (userId, sid) = Auth();
            var cart = await _carts.GetOrCreateAsync(userId, sid);

            var product = await _products.GetByIdAsync(productId);
            if (product == null) return NotFound();

            await _carts.AddItemAsync(cart, productId, Math.Max(1, qty), product.Price);
            await _carts.ReloadAsync(cart);

            var totalQty = cart.Items.Sum(i => i.Quantity);

            await cartHub.Clients.All.SendAsync("ItemAddedToCart", new
            {
                productId,
                name = product.Name,
                quantity = qty,
                totalQuantity = totalQty
            });


            TempData["Ok"] = $"{product.Name} added to cart.";
            return !string.IsNullOrWhiteSpace(returnUrl)
                ? LocalRedirect(returnUrl)
                : RedirectToAction(nameof(Index));
        }

        // ===== update qty =====
        [HttpPost("update")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update(int productId, int qty)
        {
            var (userId, sid) = Auth();
            var cart = await _carts.GetOrCreateAsync(userId, sid);

            await _carts.UpdateQuantityAsync(cart, productId, qty);
            await _carts.ReloadAsync(cart);

            TempData["Ok"] = "Quantity updated.";
            return RedirectToAction(nameof(Index));
        }

        // ===== remove line =====
        [HttpPost("remove")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Remove(int productId)
        {
            var (userId, sid) = Auth();
            var cart = await _carts.GetOrCreateAsync(userId, sid);

            await _carts.RemoveItemAsync(cart, productId);
            await _carts.ReloadAsync(cart);

            TempData["Ok"] = "Item removed.";
            return RedirectToAction(nameof(Index));
        }

        // ===== clear cart =====
        [HttpPost("clear")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Clear()
        {
            var (userId, sid) = Auth();
            var cart = await _carts.GetOrCreateAsync(userId, sid);
            await _carts.ClearAsync(cart);
            TempData["Ok"] = "Cart cleared.";
            return RedirectToAction(nameof(Index));
        }

        // ===== proceed to checkout (placeholder) =====
        [HttpPost("checkout")]
        [ValidateAntiForgeryToken]
        public IActionResult Checkout()
        {
            // Here you would redirect to your payment/checkout flow.
            // We keep it simple and just show the cart again as the "review" step is the cart page itself.
            TempData["Ok"] = "Review your order below, then continue to payment.";
            return RedirectToAction(nameof(Index));
        }
    }
}
